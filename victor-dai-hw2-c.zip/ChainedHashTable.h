#include <stdlib.h>
#include <ctime>
#include<string>
#include <sstream>
using namespace std;
#include "SinglyLinkedList.h"


template <class S>

class ChainedHashTable {
    
    class KeyValuePair {
        public:
            string key;
            S* value;
           
            string toString() {
                stringstream ss;
                ss << "(" << this->key << ", " << value->toString() << ")";
                return ss.str();
            }
    };

    private:
        SinglyLinkedList<KeyValuePair> *hashTable;
        int bins;
        int keyLength;

    public:
        ChainedHashTable(int initBins, int initKeyLength) {
            this->bins = initBins;
            this->keyLength = initKeyLength;
            this->hashTable = new SinglyLinkedList<KeyValuePair>[initBins];
            srand((unsigned) time(0));
        }
    
        /**
        * Generates a string of digits and uppercase letters that represents the
        * key of a KeyValuePair object.
        */
        string generateKey() {
            string key {""};
            
            //created array of all possible characters: (0-9, A-Z)
            char characters[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char newKey[360]; 
            const int numChars = 36;
            for(int i = 0; i < this->keyLength; ++i) {
                int random = rand() % 36;
                newKey[i] = characters[random];
            }
            
            for(int j = 0; j < this->keyLength; j++) {
                std::string c (1, newKey[j]); //converts characters in array to Strings
                key.append(c);
            }
            return key;
        }
        
        /**
         * This method takes the key argument, which is a string, and calculates
         * and returns a number in which to put values with that key.
         */
        int hashCode(string key) {
            int binNum = 0;
            char c;
            for(int i = 0; i < this->keyLength; i++) {
                c = key[i]; //extracts each individual character
                binNum += (int)c; //converts into ASCII value
            }
            binNum %= this->bins;
            return binNum;
        }
        
        /**
         * This method finds the name,value pair in the hash table using the 
         * key argument and then returns the corresponding key. 
         * Note that if none is found, nullptr should be found.
         */
        S* get(string key) {
            int h = hashCode(key);
            SinglyLinkedList<KeyValuePair>* list = &this->hashTable[h]; 
            int index = 0;
            KeyValuePair* current = list->get(index);
            while(index < list->getSize() && current->key != key) {
                current = list->get(++index);
            }
            if(index == list->getSize()) {
                return nullptr;
            }
            else {
                return current->value;
            }
        }

        void put(string key, S* value) {
            SinglyLinkedList<KeyValuePair>* list = &this->hashTable[hashCode(key)];
            int index = 0;
            KeyValuePair* current = list->get(index);
            while(index < list->getSize() && current->key != key) {
                current = list->get(++index);
            }
            if(index == list->getSize()) {
                KeyValuePair* k = new KeyValuePair();
                k->key = key;
                k->value = value;
                list->append(k);
            }
            else {
                //delete current->value; // ????
                current->value = value; //collision case
            }
        }

        string toString() {
            stringstream ss;
            
            SinglyLinkedList<KeyValuePair>* list;
            for(int i = 0; i < this->bins; i++) {
                list = &this->hashTable[i];
                ss << list->toString() << "\n";
            }
            return ss.str();;
        }
};